#pragma once

#ifdef USE_IMGUI

class Debug
{
public:

};

#endif
