#include "Models.h"

Instncing_Character::Instncing_Character(ID3D11Device* device, const char* fbx_filename,int MAX)
{
}
