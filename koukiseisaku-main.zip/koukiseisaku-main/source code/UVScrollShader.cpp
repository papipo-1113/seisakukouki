//#include "UVScrollShader.h"
//
//#include <cstdio>
//#include <memory>
//
//#include "Misc.h"
//
//UVScrollShader::UVScrollShader(ID3D11Device* device)
//{
//	// ���_�V�F�[�_�[
//	{
//		// �t�@�C�����J��
//		FILE* fp = nullptr;
//		fopen_s(&fp, "Shader\\UVScrollVS.cso", "rb");
//		_ASSERT_EXPR_A(fp, "CSO File not found");
//
//		// �t�@�C���̃T�C�Y�����߂�
//		fseek(fp, 0, SEEK_END);
//		long csoSize = ftell(fp);
//		fseek(fp, 0, SEEK_SET);
//
//		// ��������ɒ��_�V�F�[�_�[�f�[�^���i�[����̈��p�ӂ���
//		std::unique_ptr<u_char[]> csoData = std::make_unique<u_char[]>(csoSize);
//		fread(csoData.get(), csoSize, 1, fp);
//		fclose(fp);
//
//		// ���_�V�F�[�_�[����
//		HRESULT hr = device->CreateVertexShader(csoData.get(), csoSize, nullptr, vertexShader.GetAddressOf());
//		_ASSERT_EXPR(SUCCEEDED(hr), HRTrace(hr));
//
//		// ���̓��C�A�E�g
//		D3D11_INPUT_ELEMENT_DESC inputElementDesc[] =
//		{
//			{ "POSITION", 0, DXGI_FORMAT_R32G32B32_FLOAT,    0, D3D11_APPEND_ALIGNED_ELEMENT, D3D11_INPUT_PER_VERTEX_DATA, 0 },
//			{ "COLOR",    0, DXGI_FORMAT_R32G32B32A32_FLOAT, 0, D3D11_APPEND_ALIGNED_ELEMENT, D3D11_INPUT_PER_VERTEX_DATA, 0 },
//			{ "TEXCOORD", 0, DXGI_FORMAT_R32G32_FLOAT,       0, D3D11_APPEND_ALIGNED_ELEMENT, D3D11_INPUT_PER_VERTEX_DATA, 0 },
//		};
//		hr = device->CreateInputLayout(inputElementDesc, ARRAYSIZE(inputElementDesc), csoData.get(), csoSize, inputLayout.GetAddressOf());
//		_ASSERT_EXPR(SUCCEEDED(hr), HRTrace(hr));
//	}
//
//	// �s�N�Z���V�F�[�_�[
//	{
//		// �t�@�C�����J��
//		FILE* fp = nullptr;
//		fopen_s(&fp, "Shader\\UVScrollPS.cso", "rb");
//		_ASSERT_EXPR_A(fp, "CSO File not found");
//
//		// �t�@�C���̃T�C�Y�����߂�
//		fseek(fp, 0, SEEK_END);
//		long csoSize = ftell(fp);
//		fseek(fp, 0, SEEK_SET);
//
//		// ��������Ƀs�N�Z���V�F�[�_�[�f�[�^���i�[����̈��p�ӂ���
//		std::unique_ptr<u_char[]> csoData = std::make_unique<u_char[]>(csoSize);
//		fread(csoData.get(), csoSize, 1, fp);
//		fclose(fp);
//
//		// �s�N�Z���V�F�[�_�[����
//		HRESULT hr = device->CreatePixelShader(csoData.get(), csoSize, nullptr, pixelShader.GetAddressOf());
//		_ASSERT_EXPR(SUCCEEDED(hr), HRTrace(hr));
//	}
//
//	// �萔�o�b�t�@
//	{
//		// �V�[���p�o�b�t�@
//		D3D11_BUFFER_DESC desc;
//		::memset(&desc, 0, sizeof(desc));
//		desc.Usage = D3D11_USAGE_DEFAULT;
//		desc.BindFlags = D3D11_BIND_CONSTANT_BUFFER;
//		desc.CPUAccessFlags = 0;
//		desc.MiscFlags = 0;
//		desc.ByteWidth = sizeof(CbScroll);
//		desc.StructureByteStride = 0;
//
//		HRESULT hr = device->CreateBuffer(&desc, 0, scrollConstantBuffer.GetAddressOf());
//		_ASSERT_EXPR(SUCCEEDED(hr), HRTrace(hr));
//	}
//
//	// �u�����h�X�e�[�g
//	{
//		D3D11_BLEND_DESC desc;
//		::memset(&desc, 0, sizeof(desc));
//		desc.AlphaToCoverageEnable = false;
//		desc.IndependentBlendEnable = false;
//		desc.RenderTarget[0].BlendEnable = true;
//		desc.RenderTarget[0].SrcBlend = D3D11_BLEND_SRC_ALPHA;
//		desc.RenderTarget[0].DestBlend = D3D11_BLEND_INV_SRC_ALPHA;
//		desc.RenderTarget[0].BlendOp = D3D11_BLEND_OP_ADD;
//		desc.RenderTarget[0].SrcBlendAlpha = D3D11_BLEND_ONE;
//		desc.RenderTarget[0].DestBlendAlpha = D3D11_BLEND_ZERO;
//		desc.RenderTarget[0].BlendOpAlpha = D3D11_BLEND_OP_ADD;
//		desc.RenderTarget[0].RenderTargetWriteMask = D3D11_COLOR_WRITE_ENABLE_ALL;
//
//		HRESULT hr = device->CreateBlendState(&desc, blendState.GetAddressOf());
//		_ASSERT_EXPR(SUCCEEDED(hr), HRTrace(hr));
//	}
//
//	// �[�x�X�e���V���X�e�[�g
//	{
//		D3D11_DEPTH_STENCIL_DESC desc;
//		::memset(&desc, 0, sizeof(desc));
//		desc.DepthEnable = true;
//		desc.DepthWriteMask = D3D11_DEPTH_WRITE_MASK_ALL;
//		desc.DepthFunc = D3D11_COMPARISON_LESS_EQUAL;
//
//		HRESULT hr = device->CreateDepthStencilState(&desc, depthStencilState.GetAddressOf());
//		_ASSERT_EXPR(SUCCEEDED(hr), HRTrace(hr));
//	}
//
//	// ���X�^���C�U�[�X�e�[�g
//	{
//		D3D11_RASTERIZER_DESC desc;
//		::memset(&desc, 0, sizeof(desc));
//		desc.FrontCounterClockwise = false;
//		desc.DepthBias = 0;
//		desc.DepthBiasClamp = 0;
//		desc.SlopeScaledDepthBias = 0;
//		desc.DepthClipEnable = true;
//		desc.ScissorEnable = false;
//		desc.MultisampleEnable = true;
//		desc.FillMode = D3D11_FILL_SOLID;
//		desc.CullMode = D3D11_CULL_BACK;
//		desc.AntialiasedLineEnable = false;
//
//		HRESULT hr = device->CreateRasterizerState(&desc, rasterizerState.GetAddressOf());
//		_ASSERT_EXPR(SUCCEEDED(hr), HRTrace(hr));
//	}
//
//	// �T���v���X�e�[�g
//	{
//		D3D11_SAMPLER_DESC desc;
//		::memset(&desc, 0, sizeof(desc));
//		desc.MipLODBias = 0.0f;
//		desc.MaxAnisotropy = 1;
//		desc.ComparisonFunc = D3D11_COMPARISON_NEVER;
//		desc.MinLOD = -FLT_MAX;
//		desc.MaxLOD = FLT_MAX;
//		desc.BorderColor[0] = 1.0f;
//		desc.BorderColor[1] = 1.0f;
//		desc.BorderColor[2] = 1.0f;
//		desc.BorderColor[3] = 1.0f;
//		//D3D11_TEXTURE_ADDRESS_WRAP = ���[�v����
//		//D3D11_TEXTURE_ADDRESS_MIRROR = ���[�v����@����]����x���]����
//		//D3D11_TEXTURE_ADDRESS_CLAMP = ���[�v���Ȃ�
//		//D3D11_TEXTURE_ADDRESS_BORDER = ���[�v���Ȃ��X�N���[���d�؂��������͓h��Ԃ����
//		//D3D11_TEXTURE_ADDRESS_MIRROR_ONCE = ���[�v���Ȃ���񔽓]����
//		desc.AddressU = D3D11_TEXTURE_ADDRESS_CLAMP;//u���W (x���W)
//		desc.AddressV = D3D11_TEXTURE_ADDRESS_CLAMP;//v���W (y���W)
//		desc.AddressW = D3D11_TEXTURE_ADDRESS_CLAMP;//w���W (�����x)
//		desc.Filter = D3D11_FILTER_MIN_MAG_MIP_LINEAR;
//
//		HRESULT hr = device->CreateSamplerState(&desc, samplerState.GetAddressOf());
//		_ASSERT_EXPR(SUCCEEDED(hr), HRTrace(hr));
//	}
//}
//
//// �`��J�n
//void UVScrollShader::Begin(const RenderContext& rc)
//{
//	rc.deviceContext->VSSetShader(vertexShader.Get(), nullptr, 0);
//	rc.deviceContext->PSSetShader(pixelShader.Get(), nullptr, 0);
//	rc.deviceContext->IASetInputLayout(inputLayout.Get());
//
//	rc.deviceContext->IASetIndexBuffer(nullptr, DXGI_FORMAT_UNKNOWN, 0);
//	rc.deviceContext->IASetPrimitiveTopology(D3D11_PRIMITIVE_TOPOLOGY_TRIANGLESTRIP);
//
//	ID3D11Buffer* constantBuffers[] =
//	{
//		scrollConstantBuffer.Get(),
//	};
//	rc.deviceContext->VSSetConstantBuffers(0, ARRAYSIZE(constantBuffers), constantBuffers);
//	rc.deviceContext->PSSetConstantBuffers(0, ARRAYSIZE(constantBuffers), constantBuffers);
//
//	const float blend_factor[4] = { 1.0f, 1.0f, 1.0f, 1.0f };
//	rc.deviceContext->OMSetBlendState(blendState.Get(), blend_factor, 0xFFFFFFFF);
//	rc.deviceContext->OMSetDepthStencilState(depthStencilState.Get(), 0);
//	rc.deviceContext->RSSetState(rasterizerState.Get());
//	rc.deviceContext->PSSetSamplers(0, 1, samplerState.GetAddressOf());
//}
//
//// �`��
//void UVScrollShader::Draw(const RenderContext& rc, const Sprite* sprite)
//{
//	CbScroll cbScroll;
//	cbScroll.uvScrollValue = rc.uvScrollData.uvScrollValue;
//	rc.deviceContext->UpdateSubresource(scrollConstantBuffer.Get(), 0, 0, &cbScroll, 0, 0);
//
//	UINT stride = sizeof(Sprite::Vertex);
//	UINT offset = 0;
//	rc.deviceContext->IASetVertexBuffers(0, 1, sprite->GetVertexBuffer().GetAddressOf(), &stride, &offset);
//	rc.deviceContext->PSSetShaderResources(0, 1, sprite->GetShaderResourceView().GetAddressOf());
//	rc.deviceContext->Draw(4, 0);
//
//}
//
//// �`��I��
//void UVScrollShader::End(const RenderContext& rc)
//{
//	rc.deviceContext->VSSetShader(nullptr, nullptr, 0);
//	rc.deviceContext->PSSetShader(nullptr, nullptr, 0);
//	rc.deviceContext->IASetInputLayout(nullptr);
//}
