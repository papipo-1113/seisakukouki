#pragma once
#include <DirectXMath.h>


struct vertex //���_�̐ݒ�
{
	DirectX::XMFLOAT3 position;
	DirectX::XMFLOAT4 color;
	DirectX::XMFLOAT2 texcoord; //
};

